change to apply in non-DNS server enviroment
